# battle-pass-api
The BattlePass v3 API only version

All documentation can be found here: https://github.com/Hyfe-JavaDebug/battlepass-wiki-v3/wiki/Developer-API---Implementing

If you need some help, feel free to join the TitanLabs Discord here: https://discord.gg/jtm49aC
