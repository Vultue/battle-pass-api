package io.github.battlepass.cache;

import io.github.battlepass.BattlePlugin;

public interface RewardCache {
}
