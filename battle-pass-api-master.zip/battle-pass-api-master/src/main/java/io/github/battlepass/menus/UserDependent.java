package io.github.battlepass.menus;

public interface UserDependent {

    boolean isUserViable();
}